/*
 * UnaryOpF.h
 *
 *  Created on: Oct 4, 2014
 *      Author: reid
 */

#pragma once

#include "CuFunctor.h"

/*
 *
 *  UnaryOpF
 *  functors that operate on a single input (of same datatype as state and output)
 *
 *
 */

template<typename T, int StateDim> struct UnaryOpF: public CuFunctor<T, StateDim> {

	// the typedef and member decl of the member function pointer used to insure that
	// a subfunctor instance passed via a base functor still executes its operator
	typedef T (UnaryOpF<T,StateDim>::*unaryOpMethod)(T)const;
	unaryOpMethod operation;

	/*
	 * method table [datatype][gpu][method enum as idx]
	 */
	static unaryOpMethod h_Methods[MAX_GPUS][UopLast];

	__host__ __device__ T operator()(T xi) const {
		return  (this->*operation)(xi);
	}

	__host__ __device__ void init(int currDev) {
		operation = 0;
	}
};


// stateless unary operand functors

template<typename T>
struct sigmoidUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (static_cast<T>(1.) / (static_cast<T>(1.) + static_cast<T>(exp(-xi))));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("sigmoidUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &sigmoidUnaryOp<T>::operator();
	#else
		printf("sigmoidUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSigmoidUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSigmoidUnaryOp];
	#endif
	}
};



template<typename T>
struct sigmoidGradientUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		T t = (static_cast<T>(1.) / (static_cast<T>(1) + static_cast<T>(exp(-xi))));
		return t * (1. - t);
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("sigmoidGradientUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &sigmoidGradientUnaryOp<T>::operator();
	#else
		printf("sigmoidGradientUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSigmoidGradientUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSigmoidGradientUnaryOp];
	#endif
	}
};

template<typename T>
struct negateUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (static_cast<T>(-xi));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("negateUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &negateUnaryOp<T>::operator();
	#else
		printf("negateUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sNegateUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sNegateUnaryOp];
	#endif
	}
};
template<typename T> struct logUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (static_cast<T>(log(xi)));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("logUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &logUnaryOp<T>::operator();
	#else
		printf("logUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sLogUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sLogUnaryOp];
	#endif
	}
};
template<typename T> struct oneOverUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (static_cast<T>(1.) / static_cast<T>(xi));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("oneOverUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &oneOverUnaryOp<T>::operator();
	#else
		printf("oneOverUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sOneOverUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sOneOverUnaryOp];
	#endif
	}
};
template<typename T> struct expUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__
	T operator()(T xi) const {
		return (static_cast<T>(exp(xi)));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("expUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &expUnaryOp<T>::operator();
	#else
		printf("expUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sExpUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sExpUnaryOp];
	#endif
	}
};


template<typename T> struct sqrtUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (static_cast<T>(sqrt(xi)));
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("sqrtUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &sqrtUnaryOp<T>::operator();
	#else
		printf("sqrtUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSqrtUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSqrtUnaryOp];
	#endif
	}
};

template<typename T> struct sqrUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T xi) const {
		return (xi * xi);
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("sqrUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &sqrUnaryOp<T>::operator();
	#else
		printf("sqrUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSqrUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSqrUnaryOp];
	#endif
	}
};

template<typename T> struct slowInvSqrt: public UnaryOpF<T,0> {
	__host__ __device__
	T operator()(T xi) const {
		return static_cast<T>(1) / sqrt(xi);
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("slowInvSqrt.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &slowInvSqrt<T>::operator();
	#else
		printf("slowInvSqrt %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSlowInvSqrt]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sSlowInvSqrt];
	#endif
	}
};

template<typename T> struct approxInvSqrt: public UnaryOpF<T,0> {
	__host__ __device__
	T operator()(T xi) const {
		return static_cast<T>(1) / sqrt(xi);
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("approxInvSqrt.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &approxInvSqrt<T>::operator();
	#else
		printf("approxInvSqrt %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sApproxInvSqrt]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sApproxInvSqrt];
	#endif
	}
};

template<typename T> struct oneOrZeroBoolUnaryOp: public UnaryOpF<T,0> {
	__host__ __device__ T operator()(T t) const {
		return (t == 0 || t == 1);
	}
	__host__ __device__ void init(int currentDevice ) {
		printf("oneOrZeroBoolUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,0>::operation =(typename UnaryOpF<T,0>::unaryOpMethod) &oneOrZeroBoolUnaryOp<T>::operator();
	#else
		printf("oneOrZeroBoolUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sOneOrZeroBoolUnaryOp]);
		UnaryOpF<T,0>::operation =  UnaryOpF<T,0>::h_Methods[currentDevice][Uop0sOneOrZeroBoolUnaryOp];
	#endif
	}
};


template<typename T> struct powUnaryOp: public UnaryOpF<T,1> {
	__host__ __device__ T& exponent() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& exponent_ro() const { return CuFunctor<T,1>::state; }

	__host__ __device__ T operator()(T xi) const {
		return powf(xi, exponent_ro());
	}
	__host__ __device__ void init(int currentDevice, T _exponent = 0 ) {
		printf("powUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &powUnaryOp<T>::operator();
	#else
		printf("powUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sPowUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sPowUnaryOp];
	#endif
		exponent() = _exponent;
	}
};

template<typename T> struct scaleUnaryOp: public UnaryOpF<T,1> {
	__host__ __device__ T& multiplicand() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& multiplicand_ro() const { return CuFunctor<T,1>::state; }

	__host__ __device__ T operator()(T xi) const {
		return (xi * multiplicand_ro());
	}
	__host__ __device__ void init(int currentDevice, T _multiplicand = 0 ) {
		printf("scaleUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &scaleUnaryOp<T>::operator();
	#else
		printf("scaleUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sScaleUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sScaleUnaryOp];
	#endif
		multiplicand() = _multiplicand;
	}
};

template<typename T> struct translationUnaryOp: public UnaryOpF<T,1> {
	__host__ __device__ T& addend() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& addend_ro() const { return CuFunctor<T,1>::state; }

	__host__ __device__ T operator()(T xi) const {
		return (xi + addend_ro());
	}
	__host__ __device__ void init(int currentDevice, T _addend = 0 ) {
		printf("translationUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &translationUnaryOp<T>::operator();
	#else
		printf("translationUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sTranslationUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sTranslationUnaryOp];
	#endif
		addend() = _addend;
	}
};

template<typename T> struct subFromUnaryOp: public UnaryOpF<T,1> {
	__host__ __device__ T& source() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& source_ro() const { return CuFunctor<T,1>::state; }

	__host__ __device__ T operator()(T xi) const {
		return (source_ro() - xi);
	}
	__host__ __device__ void init(int currentDevice, T _source = 0 ) {
		printf("subFromUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &subFromUnaryOp<T>::operator();
	#else
		printf("subFromUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sSubFromUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sSubFromUnaryOp];
	#endif
		source() = _source;
	}
};



template<typename T> struct UnaryCompOp: public UnaryOpF<T,1> {
	__host__ __device__ T& comp() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& comp_ro() const { return CuFunctor<T,1>::state; }
};

template<typename T> struct ltUnaryOp: public UnaryCompOp<T> {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t < comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("ltUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &ltUnaryOp<T>::operator();
	#else
		printf("ltUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sLtUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sLtUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct lteUnaryOp: public UnaryCompOp<T>  {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t <= comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("lteUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &lteUnaryOp<T>::operator();
	#else
		printf("lteUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sLteUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sLteUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct gtUnaryOp: public UnaryCompOp<T> {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t > comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("gtUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &gtUnaryOp<T>::operator();
	#else
		printf("gtUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sGtUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sGtUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct gteUnaryOp: public UnaryCompOp<T> {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t >= comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("gteUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &gteUnaryOp<T>::operator();
	#else
		printf("gteUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sGteUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sGteUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct eqUnaryOp: public UnaryCompOp<T>  {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t == comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("eqUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &eqUnaryOp<T>::operator();
	#else
		printf("eqUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sEqUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sEqUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct neqUnaryOp: public UnaryCompOp<T> {
	using UnaryCompOp<T>::comp;
	using UnaryCompOp<T>::comp_ro;
	__host__ __device__ T operator()(T t) const {
		return (t != comp_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 ) {
		printf("neqUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,1>::operation =(typename UnaryOpF<T,1>::unaryOpMethod) &neqUnaryOp<T>::operator();
	#else
		printf("neqUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sNeqUnaryOp]);
		UnaryOpF<T,1>::operation =  UnaryOpF<T,1>::h_Methods[currentDevice][Uop1sNeqUnaryOp];
	#endif
		comp() = _comp;
	}
};

template<typename T> struct UnaryEpsCompOp: public UnaryOpF<T,2> {
	__host__ __device__ T& comp() { return CuFunctor<T,2>::state.x; }
	__host__ __device__ const T& comp_ro() const { return CuFunctor<T,2>::state.x; }
	__host__ __device__ T& eps() { return CuFunctor<T,2>::state.y; }
	__host__ __device__ const T& eps_ro() const { return CuFunctor<T,2>::state.y; }
};


template<typename T> struct almostEqUnaryOp: public UnaryEpsCompOp<T> {
	using UnaryEpsCompOp<T>::comp;
	using UnaryEpsCompOp<T>::comp_ro;
	using UnaryEpsCompOp<T>::eps;
	using UnaryEpsCompOp<T>::eps_ro;
	__host__ __device__ T operator()(T t) const {
		return fabs(t - comp_ro()) < eps_ro();
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 , T _eps= 1e-6 ) {
		printf("notEqualsBoolUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,2>::operation =(typename UnaryOpF<T,2>::unaryOpMethod) &almostEqUnaryOp<T>::operator();
	#else
		printf("notEqualsBoolUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,2>::h_Methods[currentDevice][Uop2sAlmostEqUnaryOp]);
		UnaryOpF<T,2>::operation =  UnaryOpF<T,2>::h_Methods[currentDevice][Uop2sAlmostEqUnaryOp];
	#endif
		comp() = _comp;
		eps() = _eps;
	}
};

template<typename T> struct notAlmostEqUnaryOp: public UnaryEpsCompOp<T> {
	using UnaryEpsCompOp<T>::comp;
	using UnaryEpsCompOp<T>::comp_ro;
	using UnaryEpsCompOp<T>::eps;
	using UnaryEpsCompOp<T>::eps_ro;
	__host__ __device__ T operator()(T t) const {
		return (fabs(t - comp_ro()) > eps_ro());
	}
	__host__ __device__ void init(int currentDevice, T _comp = 0 , T _eps= 1e-6 ) {
		printf("notAlmostEqUnaryOp.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpF<T,2>::operation =(typename UnaryOpF<T,2>::unaryOpMethod) &notAlmostEqUnaryOp<T>::operator();
	#else
		printf("notAlmostEqUnaryOp %p setting operation to %p\n",this, UnaryOpF<T,2>::h_Methods[currentDevice][Uop2sNotAlmostEqUnaryOp]);
		UnaryOpF<T,2>::operation =  UnaryOpF<T,2>::h_Methods[currentDevice][Uop2sNotAlmostEqUnaryOp];
	#endif
		comp() = _comp;
		eps() = _eps;
	}
};



