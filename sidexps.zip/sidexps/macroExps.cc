/*
 * macroExps.cc
 *
 *  Created on: Jun 6, 2014
 *      Author: reid
 */

#include <iostream>


#define abs_bomb 0,-1
#define ABSbad(a) ((a)<0?-(a):a)
#define ABS(a) ((a)<0?-(a):a)
using namespace std;
int main(void) {
	cout << "hello ABSbad(abs_bomb) " << ABSbad(abs_bomb) << endl;
}
class B
{
public:
   virtual void f(short,int) {std::cout << "B::f" << std::endl;}
};

class D : public B
{
public:
   virtual void f(int) {std::cout << "D::f" << std::endl;}
};
