/*
 * printname.cc
 *
 *  Created on: Jul 6, 2014
 *      Author: reid
 */




#include <iostream>

struct printname {
	 template<class T>

  void operator()(const T& t) { std::cout<<t<<std::endl; }
};

template<class T>
struct printname2 {
  void operator()(const T& t) { std::cout<<t<<std::endl; }
};

template<class T, class F>
void applyfunc(const T& t, F f) { f(t); }

//template <template <typename> class BinaryOp>
template<class T, template <typename> class F>
void applyfunc2(const T& t, F<T> f) { f(t); }

int main(){
  const int a=1;
  // can infer type
  applyfunc(a, printname());
  applyfunc2(a, printname2<int>());
  applyfunc(a, printname2<char>());
  return 0;
}
