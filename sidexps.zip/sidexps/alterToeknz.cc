/*
 * alterToeknz.cc
 *
 *  Created on: Jul 11, 2014
 *      Author: reid
 */


%:include <iostream>
%:include <stdlib.h>
struct Test {
  int data;
  void * mydat;
  Test() : data(5) { std::cout << "Test::Test() this " << this << std::endl;  mydat = malloc(data);}
  ~Test() { std::cout << "Test::~Test() this " << this << std::endl; free(mydat); }
};

int main(int argc, char *argv<::>)
<%
	Test test1;
	void* ptest = malloc(sizeof(Test));
	new (ptest) Test();
	((Test*)ptest)->~Test();
	free(ptest);


    if (argc > 1 and argv<:1:> not_eq '\0') <%
        std::cout << "Hello " << argv<:1:> << '\n';
    %>
%>

