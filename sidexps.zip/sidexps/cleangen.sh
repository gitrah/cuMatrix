# !/bin/sh
# 
rm -f UnaryOpF.h BinaryOpF.h UnaryOpIndexF.h FunctorEnums.h MethodTableMgr.cu a.out
