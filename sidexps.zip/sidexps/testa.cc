/*
 * testa.cc
 *
 *  Created on: Aug 29, 2014
 *      Author: reid
 */

#include <iostream>
#include "parta.h"

int main() {
	std::cout << "testa.cc main enter\n";
	partA* pa = new partA();
	std::cout << "created a partA at " << pa << "\n";
	pa->sayHello();
	std::cout << "deleting partA at " << pa << "\n";
	delete pa;
}


