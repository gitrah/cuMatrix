
/*
 * parta.cc
 *
 *  Created on: Aug 29, 2014
 *      Author: reid
 */
#include "parta.h"
#include <iostream>

partA::partA() {
}

partA::~partA() {
}

void partA::sayHello() {
	std::cout << "Hello from partA at " << this << "\n";
}


