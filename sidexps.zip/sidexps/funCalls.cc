/*
 * funCalls.cc
 *
 *  Created on: Jul 11, 2014
 *      Author: reid
 */
struct MyClass {
	int a;
	float b;
};

int fByV(MyClass m) {
	MyClass m2;
	m2.a = m.a;
	return m2.a;
}
int fByR(MyClass& m) {
	MyClass m2;
	m2.a = m.a;
	return m2.a;
}
int fByCR(const MyClass& m) {
	MyClass m2;
	m2.a = m.a;
	return m2.a;
}

int main() {
	MyClass m;
	m.a=5;
	m.b = 6.f;
	fByV(m);
	fByR(m);
	fByCR(m);
	return 0;
}


