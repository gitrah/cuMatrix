


#ifndef PARTA_H_
#define PARTA_H_

class partA {
public:
	partA();
	~partA();

	void sayHello();
};
#endif

