/*
 * Statelet.h
 *
 *  Created on: Sep 12, 2014
 *      Author: reid
 */

//#ifndef STATELET_H_
//define STATELET_H_
#include <iostream>
using namespace std;
typedef unsigned int uint;
template <typename T, int Dim> struct Statelet;

template <typename T> struct Functor {
	typedef T (*oneArgFnPtr)(Statelet<T,1>&, uint);
	oneArgFnPtr fptr;
	T operator()(Statelet<T,1>&s, uint idx) {
		return (*fptr)(s, idx);
	}
};

template <typename T, int Dim> struct Statelet {
	T state[Dim];
	Functor<T> ftor;
	friend class Functor<T>;
};

template <typename T> T firstState(Statelet<T,1>& s, uint idx) {
	return s.state[0];
}

int main() {
	Functor<float> ftr;
	ftr.fptr = firstState;
	Statelet<float,1> s;
	s.state[0] = 50;
	cout << "s.ftor(5)  " << ftr(s,5) << endl;
	return 0;
}
//#endif /* STATELET_H_ */
