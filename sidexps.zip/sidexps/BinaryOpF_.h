/*
 * BinaryOpF.h
 *
 *  Created on: Oct 4, 2014
 *      Author: reid
 */

#pragma once
#include "CuFunctor.h"
template<typename T,int StateDim> struct BinaryOpF: public CuFunctor<T,StateDim> {
	typedef T (BinaryOpF<T,StateDim>::*binaryOpMethod)(T,T)const;
	binaryOpMethod operation;


	__host__ __device__ void print() {
		printf("mesize %lu, tsize %d, dis %p\n", sizeof(*this),
				sizeof(T), this);
	}

	/*
	 * method table [datatype][gpu][method enum as idx]
	 */
	static binaryOpMethod h_Methods[MAX_GPUS][BopLast];

	__host__ __device__ T operator()(T xi1, T xi2) {
		return  (this->*operation)(xi1,xi2);
	}

	__host__ __device__ void init(int currDev) {
		operation = 0;
	}
};

template<typename T,int StateDim> struct MonoidF : public BinaryOpF<T,StateDim> {
	using BinaryOpF<T,StateDim>::operator();
	__host__ __device__ T& identity() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& identity_ro() const { return CuFunctor<T,1>::state; }
};

template<typename T>
struct multBinaryOp: public MonoidF<T,1> {
	using MonoidF<T,1>::identity;
	using MonoidF<T,1>::identity_ro;

	__host__ __device__
	T operator()(T xi, T xi2) const {
		printf("multBinaryOp.operator() xi %f, xi2 %f\n",xi,xi2);
		return (xi * xi2);
	}

	__host__ __device__ void init(int currentDevice) {
		printf("multBinaryOp.init\n");
	#ifdef __CUDA_ARCH__
		BinaryOpF<T,1>::operation =(typename BinaryOpF<T,1>::binaryOpMethod) &multBinaryOp<T>::operator();
	#else
		printf("multBinaryOp %p setting operation to %p\n",this, BinaryOpF<T,1>::h_Methods[currentDevice][Bop1s_multBinaryOp]);
		BinaryOpF<T,1>::operation =  BinaryOpF<T,1>::h_Methods[currentDevice][Bop1s_multBinaryOp];
	#endif
		identity() = 1;
	}
};


template<typename T, template <typename> class Function>
struct rootBracketingBinaryOp: public BinaryOpF<T,0> {
	__host__ __device__
	T operator()(T xi, T xi2) const {
		return sign(func(xi)) != sign(func(xi2)) || xi == 0 || xi2 == 0;
	}
	__host__ __device__ void init(int currentDevice) {
		printf("multBinaryOp.init\n");
	#ifdef __CUDA_ARCH__
		BinaryOpF<T,0>::operation =(typename BinaryOpF<T,0>::binaryOpMethod) &rootBracketingBinaryOp<T>::operator();
	#else
		printf("multBinaryOp %p setting operation to %p\n",this, BinaryOpF<T,0>::h_Methods[currentDevice][Bop0s_rootBracketingBinaryOp]);
		BinaryOpF<T,0>::operation =  BinaryOpF<T,0>::h_Methods[currentDevice][Bop0s_rootBracketingBinaryOp];
	#endif
	}

};
