#pragma once
#include <cuda_runtime.h>

#define MAX_GPUS 10
#define Pi 3.141592653589793
#ifndef MIN
#define MIN(x,y) ((x < y) ? x : y)
#endif

__host__ __device__ const char *__cudaGetErrorEnum(cudaError_t error);

#define cherr(exp) if((exp)!= cudaSuccess) {printf( "%s : %d --> %s\n", __FILE__, __LINE__ , __cudaGetErrorEnum(exp));assert(0);}
