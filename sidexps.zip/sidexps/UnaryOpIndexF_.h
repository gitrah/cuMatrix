/*
 * CuFillers.h
 *
 *  Created on: Oct 4, 2014
 *      Author: reid
 */
#pragma once
#include "UnaryOpF.h"

/*
 * Base 'filler' functor (whose subclasses impl functions of a 1-d index)
 */
template<typename T,int StateDim> struct UnaryOpIndexF : public CuFunctor<T,StateDim> {

	// this member will hold a pointer to the subclass's impl of the operator()(uint) method
	typedef T (UnaryOpIndexF<T,StateDim>::*uintMethod)(uint)const;
	uintMethod operation;

	//typedef T (UnaryOpIndexF<T,StateDim>::**uintMethodArray)(uint)const;
	//typedef T (UnaryOpIndexF<T,StateDim>::***uintMethodArrayGrid)(uint)const;

	static uintMethod h_Methods[MAX_GPUS][IopLast];
	__host__ __device__ T operator()(uint idx) {
		return  (this->*operation)(idx);
	}

	__host__ __device__ void init(int currDev) {
		operation = 0;
	}
};

template<typename T>
struct oneOverIdxFiller: public UnaryOpIndexF<T,0> {
	__host__ __device__ T operator()(uint idx) {
		return 1. / static_cast<T>(1 + idx);
	}
	__host__ __device__ void init(int currentDevice) {
		printf("oneOverIdxFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,0>::operation =(typename UnaryOpIndexF<T,0>::uintMethod) &oneOverIdxFiller<T>::operator();
	#else
		printf("oneOverIdxFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,0>::h_Methods[currentDevice][Iop0sOneOver]);
		UnaryOpIndexF<T,0>::operation =  UnaryOpIndexF<T,0>::h_Methods[currentDevice][Iop0sOneOver];
	#endif
	}
};

template<typename T>
struct sinFiller: public UnaryOpIndexF<T,3> {

	__host__ __device__ T& amplitude() { return CuFunctor<T,3>::state.x; }
	__host__ __device__ const T& amplitude_ro() const { return CuFunctor<T,3>::state.x; }

	__host__ __device__ T& period() { return CuFunctor<T,3>::state.y; }
	__host__ __device__ const T& period_ro() const { return CuFunctor<T,3>::state.y; }

	__host__ __device__ T& phase() { return CuFunctor<T,3>::state.z; }
	__host__ __device__ const T& phase_ro() const { return CuFunctor<T,3>::state.z; }

	__host__ __device__ T operator()(uint idx) const {
		return static_cast<T>(amplitude_ro() * ::sin(2. * Pi *  (idx - phase_ro())/ period_ro() ));
	}

	__host__ __device__ void init(int currentDevice, T _amplitude = 1, T _period = 2 * Pi, T _phase = 0) {
		printf("sinFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,3>::operation =(typename UnaryOpIndexF<T,3>::uintMethod) &sinFiller<T>::operator();
	#else
		printf("sinFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sSin]);
		UnaryOpIndexF<T,3>::operation =  UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sSin];
	#endif
		amplitude()= _amplitude;
		period() = _period;
		phase() = _phase;
	}

};

template<typename T>
struct cosFiller: public sinFiller<T> {
	using sinFiller<T>::amplitude;
	using sinFiller<T>::amplitude_ro;
	using sinFiller<T>::phase;
	using sinFiller<T>::phase_ro;
	using sinFiller<T>::period;
	using sinFiller<T>::period_ro;
	__host__ __device__ T operator()( uint idx) const {
		return static_cast<T>(amplitude_ro() * ::cos(2. * Pi * (idx +  phase_ro()) /  period_ro()));
	}
	__host__ __device__ void init(int currentDevice, T _amplitude = 1, T _period = 2 * Pi, T _phase = 0) {
		printf("cosFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,3>::operation =(typename UnaryOpIndexF<T,3>::uintMethod) &cosFiller<T>::operator();
	#else
		printf("cosFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sCos]);
		UnaryOpIndexF<T,3>::operation =  UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sCos];
	#endif
		amplitude() = _amplitude;
		period() = _period;
		phase() = _phase;
	}
};

template<typename T>
struct spanFiller: public UnaryOpIndexF<T, 3> {
	__host__ __device__ T& start() { return CuFunctor<T,3>::state.x; }
	__host__ __device__ const T& start_ro() const { return CuFunctor<T,3>::state.x; }

	__host__ __device__ T& end() { return CuFunctor<T,3>::state.y; }
	__host__ __device__ const T& end_ro() const { return CuFunctor<T,3>::state.y; }

	__host__ __device__ T& steps() { return CuFunctor<T,3>::state.z; }
	__host__ __device__ const T& steps_ro() const { return CuFunctor<T,3>::state.z; }

	__host__ __device__ T operator()(uint idx) const {
		return static_cast<T>(start_ro() + idx * (end_ro()- start_ro()) / steps_ro());
	}

	__host__ __device__ void init(int currentDevice, T start = 0, T end = 10, T steps = 10) {
		printf("spanFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,3>::operation =(typename UnaryOpIndexF<T,3>::uintMethod) &spanFiller<T>::operator();
	#else
		printf("spanFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sSpan]);
		UnaryOpIndexF<T,3>::operation =  UnaryOpIndexF<T,3>::h_Methods[currentDevice][Iop3sSpan];
	#endif
		start()=start;
		end()=end;
		steps()= steps;
	}
};

template<typename T>
struct sequenceFiller: public UnaryOpIndexF<T,1> {
	__host__ __device__ T& phase() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& phase_ro() const { return CuFunctor<T,1>::state; }
	__host__ __device__  T operator()(uint idx)const {
		return static_cast<T>(idx + phase_ro());
	}
	__host__ __device__ void init(int currentDevice, T _phase = 0) {
		printf("sequenceFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,1>::operation =(typename UnaryOpIndexF<T,1>::uintMethod) &sequenceFiller<T>::operator();
	#else
		printf("sequenceFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sSequence]);
		UnaryOpIndexF<T,1>::operation =  UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sSequence];
	#endif
		phase()=_phase;
	}
};

template<typename T>
struct increasingColumnsFiller: public UnaryOpIndexF<T,2> {
	__host__ __device__ T& start() { return CuFunctor<T,2>::state.x; }
	__host__ __device__ const T& start_ro() const { return CuFunctor<T,2>::state.x; }

	__host__ __device__ T& cols() { return CuFunctor<T,2>::state.y; }
	__host__ __device__ const T& cols_ro() const { return CuFunctor<T,2>::state.y; }
	__host__ __device__  T operator()(uint idx) const {
		return static_cast<T>(start_ro() + (idx % static_cast<uint>(cols_ro()) ) );
	}
	__host__ __device__ void init(int currentDevice, T _start=0, T _cols = 10) {
		printf("increasingColumnsFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,2>::operation =(typename UnaryOpIndexF<T,2>::uintMethod) &increasingColumnsFiller<T>::operator();
	#else
		printf("increasingColumnsFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sIncreasingCols]);
		UnaryOpIndexF<T,2>::operation =  UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sIncreasingCols];
	#endif
		start() = _start;
		cols() = _cols;
	}
};

template<typename T>
struct increasingRowsFiller : public UnaryOpIndexF<T,2> {
	__host__ __device__ T& start() { return CuFunctor<T,2>::state.x; }
	__host__ __device__ const T& start_ro() const { return CuFunctor<T,2>::state.x; }

	__host__ __device__ T& rows() { return CuFunctor<T,2>::state.y; }
	__host__ __device__ const T& rows_ro() const { return CuFunctor<T,2>::state.y; }
	__host__ __device__ T operator()(uint idx) const {
		return static_cast<T>(start_ro() + (idx / static_cast<uint>(rows_ro())));
	}
	__host__ __device__ void init(int currentDevice, T _start = 0, T _rows = 10) {
		printf("increasingRowsFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,2>::operation =(typename UnaryOpIndexF<T,2>::uintMethod) &increasingRowsFiller<T>::operator();
	#else
		printf("increasingRowsFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sIncreasingRows]);
		UnaryOpIndexF<T,2>::operation =  UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sIncreasingRows];
	#endif
		start() = _start;
		rows() = _rows;
	}
};

template<typename T>
struct seqModFiller: public UnaryOpIndexF<T,2> {
	__host__ __device__ T& phase() { return CuFunctor<T,2>::state.x; }
	__host__ __device__ const T& phase_ro() const { return CuFunctor<T,2>::state.x; }
	__host__ __device__ T& mod() { return CuFunctor<T,2>::state.y; }
	__host__ __device__ const T& mod_ro() const { return CuFunctor<T,2>::state.y; }
	__host__ __device__ T operator()(uint idx) const {
		return static_cast<T>((idx + static_cast<uint>(phase_ro()))
				% static_cast<uint>(mod_ro()));
	}
	__host__ __device__ void init(int currentDevice, T _phase = 0, T _mod = 1) {
		printf("seqModFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,2>::operation =(typename UnaryOpIndexF<T,2>::uintMethod) &seqModFiller<T>::operator();
	#else
		printf("seqModFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sSeqMod]);
		UnaryOpIndexF<T,2>::operation =  UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sSeqMod];
	#endif
		phase() = _phase;
		mod() = _mod;
	}
};

template<typename T>
struct constFiller : public UnaryOpIndexF<T,1> {
	__host__ __device__ constFiller() {}

	__host__ __device__ T& value() { return CuFunctor<T,1>::state; }
	__host__ __device__ const T& value_ro() const { return CuFunctor<T,1>::state; }

	__host__ __device__ T operator()(uint idx) const {
		return CuFunctor<T,1>::state;
	}

	__host__ __device__ void init(int currentDevice, T _value = 0) {
		printf("constFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,1>::operation =(typename UnaryOpIndexF<T,1>::uintMethod) &constFiller<T>::operator();
	#else
		//assert(SetupMbrFuncs == true);
		printf("constFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sConst]);
		UnaryOpIndexF<T,1>::operation =  UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sConst];
	#endif
		value()= _value;
	}
};

template<typename T>
struct diagonalFiller: public UnaryOpIndexF<T,2> {
	__host__ __device__ T& value() { return CuFunctor<T,2>::state.x; }
	__host__ __device__ const T& value_ro() const { return CuFunctor<T,2>::state.x; }
	__host__ __device__ T& dim() { return CuFunctor<T,2>::state.y; }
	__host__ __device__ const T& dim_ro() const { return CuFunctor<T,2>::state.y; }

	__host__ __device__ T operator()(uint idx) const {
		return (idx /static_cast<uint>(dim_ro()) == idx % static_cast<uint>(dim_ro()) ? value_ro() : 0);
	}
	__host__ __device__ void init(int currentDevice, T _value = 0, T _dim = 10) {
		printf("diagonalFiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,2>::operation =(typename UnaryOpIndexF<T,2>::uintMethod) &diagonalFiller<T>::operator();
	#else
		printf("diagonalFiller %p setting operation to %p\n",this, UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sDiagonal]);
		UnaryOpIndexF<T,2>::operation =  UnaryOpIndexF<T,2>::h_Methods[currentDevice][Iop2sDiagonal];
	#endif
		value()= _value;
		dim()= _dim;
	}
};

template<typename T>
struct powFiller: public constFiller<T> {
	using constFiller<T>::value;
	using constFiller<T>::value_ro;

	__host__ __device__ T operator()(uint idx) const {
		if (idx == 0) {
			return (T) 1;
		}
		if (idx == 1) {
			return value_ro();
		}
		return powf( value_ro(), idx);
	}

	__host__ __device__ void init(int currentDevice, T _value = 0) {
		printf("powfiller.init\n");
	#ifdef __CUDA_ARCH__
		UnaryOpIndexF<T,1>::operation =(typename UnaryOpIndexF<T,1>::uintMethod) &powFiller<T>::operator();
	#else
		printf("powfiller %p setting operation to %p\n",this, UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sPow]);
		UnaryOpIndexF<T,1>::operation =  UnaryOpIndexF<T,1>::h_Methods[currentDevice][Iop1sPow];
	#endif
		value()= _value;
	}
};


