#!/bin/sh
g++ -c -g parta.cc -o parta.o
ar -crv parta.a parta.o
g++ -g testa.cc parta.a -o testa