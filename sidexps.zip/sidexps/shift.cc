#include <iostream>
using namespace std;
int main() {
	int t = 4;
	t = t >> 1;
	cout << "t>>1 " << t << endl;
	t = t >> 1;
	cout << "t>>1 " << t << endl;
	t = t >> 1;
	cout << "t>>1 " << t << endl;
	return 0;
}
