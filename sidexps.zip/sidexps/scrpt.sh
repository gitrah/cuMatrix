#!/bin/sh
CUMATRIX="cuMatrix"
SIDEXPS="sidexps"
thisdir=`pwd`
declare -i len
len=${#thisdir}
declare -i midx
midx=$(expr match "$thisdir" ".*/$CUMATRIX/$SIDEXPS" )
if [ $len = $midx ] 
	then 
	 echo "right dir"
	else
	  echo "seeking right dir"
	  cd "$thisdir/$SIDEXPS"
fi
touch marquer
cd $thisdir