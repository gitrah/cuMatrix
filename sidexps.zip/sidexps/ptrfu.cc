/*
 * ptrfu.cc
 *
 *  Created on: Aug 27, 2014
 *      Author: reid
 */

#include <iostream>
#include <cstdlib>

struct foo {
	int a;
	void bar() {
		std::cout << "bar a:" << a << "\n";
	}
	void blort() {
		a = a-5;
	}
};

struct foo2  : public foo {
	void bar() {
		std::cout << "foo2 bar a:" << a << "\n";
	}
};

typedef void (foo::*fooMbrPtr)();

typedef void (foo2::*foo2MbrPtr)();

void fooc(int* p) {
	new (p) int(5);
}

void foob(fooMbrPtr ptr ) {
	ptr = &foo::bar;
}

template <typename T> struct BaseFn1 {
	typedef T (BaseFn1::*baseMbrPtr)(uint) const;

	T val;
	baseMbrPtr pop;

	T operator()(uint idx) const {
		return idx/0;
	}
};

template <typename T> struct CFn1 : public BaseFn1<T> {
	T operator()(uint idx) const {
		return BaseFn1<T>::val;
	}
};

template <typename T> struct StepFn1 : public BaseFn1<T> {
	T operator()(uint idx) const {
		return BaseFn1<T>::val + idx;
	}
};

template <typename T> void doIt5times(BaseFn1<T>* p) {
	for(uint i = 0; i < 5; i++) {
		 T res = (p->*pop)(i);
		 std::cout << i << ": " << res << "\n";
	}
}

class S {
    int mf1(); // non-static member function declaration
    void mf2() volatile, mf3() &&; // can be cv-qualified and reference-qualifie
    int mf4() const { return data; } // can be defined inline
    virtual void mf5() final; // can be virtual, can use final/override
    S() : data(12) {} // constructors are member functions too
    int data;
};
int S::mf1() { return 7; } // if not defined inline, has to be defined at namespace

template<class Tt>
auto mul(Tt a, Tt b) -> decltype(a*b){
	return a*b;
}

template<typename T1, typename T2>

auto sum(T1 & t1, T2 & t2) -> decltype(t1 + t2){

return t1 + t2;

}

template<class T> class tmp {
public:
	int i;
};
tmp<int> foo() {
	return tmp<int>();
}
typedef tmp<int> (*funcReturningTmpInt)();

funcReturningTmpInt bar() {
	return foo;
}

/*
 *  if you want

   tmp<int>(*)() bar2(int);

   move func name to right after ptr pos

   tmp<int>(*)() bar2(int)

   tmp<int>(* bar2(int) ) ();

 */
tmp<int> (* bar2(int) )() {
	return foo;
}

// foo is a function whose return type is a function pointer.
// The function pointer points to a function that returns a function pointer to a function that returns tmp<int>
tmp<int> ( *(*foo() )() ) () {
	return tmp<int>();
}

auto foo2() ->
		auto (*)() -> tmp<int>(*)() {
	return 0;
}


auto multiply (int x, int y) -> int;

class Person
{
public:
    enum PersonType { ADULT, CHILD, SENIOR };
    inline void setPersonType (PersonType person_type) { _person_type = person_type; }
    PersonType getPersonTypeInnerDef () { return this->_person_type; }
  //  auto getPersonTypeOuterDef () const -> decltype(this->_person_type);
private:
    PersonType _person_type;
};
//auto Person::getPersonTypeOuterDef() const -> decltype(PersonType) {return _person_type;}


int main() {

	int *ptr = (int*) malloc(sizeof(int));
	fooc(ptr);
	std::cout << "*ptr " << *ptr << "\n";
	free(ptr);

	std::cout << "sizeof(fooMbrPtr) " << sizeof(fooMbrPtr) << "\n";
	std::cout << "sizeof(foo2MbrPtr) " << sizeof(foo2MbrPtr) << "\n";
	foo*  f = new foo2();
	f->a = 5;
	foo2MbrPtr fooPtr = &foo2::bar;
	(((foo2*)f)->*fooPtr)();
	f->bar();

	return 0;
}
