exploring c++ syntax (and some c++11 features)
