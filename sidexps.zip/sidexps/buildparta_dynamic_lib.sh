#!/bin/sh
g++ -fPIC -c -g parta.cc -o parta.o
g++ -shared -Wl,-soname,libparta.so.1 -o libparta.so.1.0 parta.o
ln -sf libparta.so.1.0 libparta.so.1
ln -sf libparta.so.1 libparta.so
#
SCRIPT=$(readlink -f $0)
SCRIPTPATH=`dirname $SCRIPT`
echo  "script\n" $SCRIPT  "\n"
echo "SCRIPTPATH " $SCRIPTPATH "\n"
g++ -g testa.cc -L$SCRIPTPATH -lparta -o testa