/*
 * refQual.cc
 *
 *  Created on: Jul 11, 2014
 *      Author: reid
 */




#include <iostream>

struct Foo {
  Foo() { std::cout << "Foo cons\n";}
  void foo() & { std::cout << "lvalue" << std::endl; }
  void foo() && { std::cout << "rvalue" << std::endl; }
};

int main() {
  Foo foo;
  foo.foo(); // Prints "lvalue"
  Foo();
  Foo().foo(); // Prints "rvalue"
  return 0;
}
