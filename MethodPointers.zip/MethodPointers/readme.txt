Sample: Method Pointers
Minimum spec: SM 3.0

This sample illustrates how to use method pointers and code generation

Key concepts:
