Sample: Method Pointers
Minimum spec: SM 3.0

This sample illustrates how to use function/method pointers and code generation

Key concepts:  

use function pointers to avoid memory expense of templating kernels by functor type
use ribosome (ruby templating script, slightly modified from Martin Sustrik's original) to
 generate boilerplate code and simplify cross-cutting changes 

To build:

'make kts=1' will produce a version where kernels are templated by functor and each functor is passed by value
     and each's operator() method is called directly
'make' by itself will produce a version where base functor's operator() method dereferences a method pointer
     to invoke subclass's operator() method
'make statFunc=1' will produce a version where base functor's operator() method dereference a function pointer 
     to each subclass functor's operator() method (converted to a static function by the ribosome script, showing its
     power to easily effect cross-cutting changes) 
